package com.lgy.ShoFriend.dto;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {
	private int id; 
	private String name; 
	private String email; 
	private String password; 
	private String phone; 
	private String address; 
	private Timestamp created_at; 
	private String zipcode; // 추가 우편번호
	private String address1; // 추가 도로명 주소
	private String address2;
}
