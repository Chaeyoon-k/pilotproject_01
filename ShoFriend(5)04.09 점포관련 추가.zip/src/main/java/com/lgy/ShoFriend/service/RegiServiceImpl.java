package com.lgy.ShoFriend.service;

import java.util.ArrayList;
import java.util.HashMap;



import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.ShoFriend.dao.RegiDAO;
import com.lgy.ShoFriend.dto.StoreDTO;


@Service("RegiService")
public class RegiServiceImpl implements RegiService{
	@Autowired
	private SqlSession sqlSession;

	
	
	//일반회원 등록
	@Override
	public void write(HashMap<String, String> param) {
	
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		dao.write(param);
		
	}


	//판매자 등록
	@Override
	public void sell_write(HashMap<String, String> param) {
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		dao.sell_write(param);
		
		
	}

//04.09 점포 관련 추가
	//점포 등록
	@Override
	public void store_write(HashMap<String, String> param) {
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		dao.store_write(param);
		
	}


	//등록한 점포 리스트
	@Override
	public ArrayList<StoreDTO> list() {
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		ArrayList<StoreDTO> list = dao.list();
		return list;
	}


	//점포수정 화면
	@Override
	public StoreDTO contentView(HashMap<String, String> param) {
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		StoreDTO dto = dao.contentView(param);
		
		return dto;
	}

	//점포 수정
	@Override
	public void store_modify(HashMap<String, String> param) {
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		dao.store_modify(param);
		
	}


	//점포 삭제
	@Override
	public void store_delete(HashMap<String, String> param) {
		RegiDAO dao=sqlSession.getMapper(RegiDAO.class);
		dao.store_delete(param);
		
	}














	

	

}
