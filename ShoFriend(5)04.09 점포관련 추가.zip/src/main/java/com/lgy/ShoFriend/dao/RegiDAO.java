package com.lgy.ShoFriend.dao;


import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgy.ShoFriend.dto.CustomerDTO;
import com.lgy.ShoFriend.dto.StoreDTO;


public interface RegiDAO {
	public void write(HashMap<String, String> param);
	public void sell_write(HashMap<String, String> param);
	
	//점포관련 추가 04-09  
	public ArrayList<StoreDTO> list();
	public void store_write(HashMap<String, String> param);
	public StoreDTO contentView(HashMap<String, String> param);
	public void store_modify(HashMap<String, String> param);
	public void store_delete(HashMap<String, String> param);
}















