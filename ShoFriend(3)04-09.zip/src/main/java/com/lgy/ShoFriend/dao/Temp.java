package com.lgy.ShoFriend.dao;

public class Temp {

}
