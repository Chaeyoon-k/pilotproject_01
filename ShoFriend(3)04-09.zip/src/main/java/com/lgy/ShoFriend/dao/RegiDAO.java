package com.lgy.ShoFriend.dao;


import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lgy.ShoFriend.dto.CustomerDTO;

public interface RegiDAO {
	public void write(HashMap<String, String> param);
	public void sell_write(HashMap<String, String> param);

}















