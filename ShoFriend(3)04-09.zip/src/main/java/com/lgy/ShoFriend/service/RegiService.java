package com.lgy.ShoFriend.service;


import java.util.HashMap;
import java.util.Optional;

import com.lgy.ShoFriend.dto.CustomerDTO;

public interface RegiService {
	public void write(HashMap<String, String> param);
	public void sell_write(HashMap<String, String> param);


}
