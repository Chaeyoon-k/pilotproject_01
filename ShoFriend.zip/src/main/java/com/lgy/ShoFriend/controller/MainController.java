package com.lgy.ShoFriend.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lgy.ShoFriend.service.RegiService;


import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MainController {
/*
* (메소드 동작 방식 기재)
* 작성일      작성자   개발내용,수정내용
* 25/04/07 
*/
	@Autowired
	private RegiService service;
	
	@RequestMapping("/login")
	public String login() {
		log.info("login()");
		return ("login");
	}
	@RequestMapping("/mypage")
	public String mypage() {
		log.info("mypage()");
		return ("mypage");
	}
//	(일반회원가입) 25.04.08 김채윤
	@RequestMapping("/register")
	public String register() {
		log.info("register()");
		return "register";
	}
	//(일반회원가입 완료) 25.04.08 김채윤
	@RequestMapping("/registerOk")

		public String registerOk(@RequestParam HashMap<String, String> param) {
		log.info("@# registerOk()");

		service.write(param);
		return "redirect:login";
	}
	
//	(판매자 회원가입) 25.04.08 김채윤
	@RequestMapping("/sell_register")
	public String sell_register() {
		log.info("sell_register()");
		return "sell_register";
	}
	//(판매자 회원가입 완료) 25.04.08 김채윤
	@RequestMapping("/sell_registerOk")

		public String sell_registerOk(@RequestParam HashMap<String, String> param) {
		log.info("@# sell_registerOk()");

		service.sell_write(param);
		return "redirect:login";
	}
	
	@PostMapping("/emailCheck")
	@ResponseBody
	public int emailCheck(@RequestParam("email") String email) {
		int cnt = service.emailCheck(email);
		return cnt;
	}
	
	@RequestMapping("/main")
	public String main() {
		log.info("main()");
		return ("main");
	}
}
